self.__MIDDLEWARE_MATCHERS = [
  {
    "regexp": "^\\/mojo(?:\\/(_next\\/data\\/[^/]{1,}))?\\/guides(?:\\/([^\\/#\\?]+?))(\\.json|\\.rsc|\\.segments\\/.+\\.segment\\.rsc)?[\\/#\\?]?$",
    "originalSource": "/guides/:slug"
  }
];self.__MIDDLEWARE_MATCHERS_CB && self.__MIDDLEWARE_MATCHERS_CB()