var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/about/opengraph-image/route.js")
R.c("server/chunks/[externals]__1xz4u76kedrnq._.js")
R.c("server/chunks/_03xyahz-ttm03._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/node_modules_next_0g8xe7c6fvfgl._.js")
R.c("server/chunks/_1fd2vvtvn-u2b._.js")
R.c("server/chunks/_next-internal_server_app_about_opengraph-image_route_actions_0n3a0iwt47uxk.js")
R.m(57216)
module.exports=R.m(57216).exports
