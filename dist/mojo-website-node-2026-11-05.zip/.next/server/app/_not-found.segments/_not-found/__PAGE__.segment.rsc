1:"$Sreact.fragment"
2:"/mojo/_next/static/chunks/0wj0noag-9_fs.js"
3:I[39756,["$2"],"default"]
4:I[37457,["$2"],"default"]
5:"/mojo/_next/static/chunks/2zdmxv_p9kk0q.js"
6:"/mojo/_next/static/chunks/1elud1o77e445.js"
7:I[22016,["$5","$6"],""]
14:"ViewportBoundary"
15:I[97367,["$2"],"$14"]
16:"MetadataBoundary"
17:I[97367,["$2"],"$16"]
18:"$Sreact.suspense"
:HL["/mojo/_next/static/chunks/2gk-sc214nqvc.css","style"]
9:X
9:C
a:X
a:300
a:C
d:X
d:C
13:X
13:C
e:[["children",{"s":"__PAGE__","h":49314,"d":{"r":["$","$1","c",{"children":[["$","main",null,{"className":"flex min-h-screen items-center justify-center px-4","children":[["$","div",null,{"aria-hidden":true,"className":"pointer-events-none fixed inset-0 -z-10 overflow-hidden","children":[["$","div",null,{"className":"absolute -left-[10%] -top-[15%] h-[55vmax] w-[55vmax] animate-drift rounded-full bg-violet/30 blur-3xl"}],["$","div",null,{"className":"absolute -right-[15%] top-[20%] h-[50vmax] w-[50vmax] animate-drift-slow rounded-full bg-teal/25 blur-3xl"}],["$","div",null,{"className":"absolute bottom-[-25%] left-[25%] h-[45vmax] w-[45vmax] animate-drift rounded-full bg-amber/15 blur-3xl"}],["$","div",null,{"className":"absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgb(29_24_56/0.06)_1px,transparent_0)] [background-size:28px_28px]"}]]}],["$","div",null,{"className":"glass max-w-md rounded-blob p-10 text-center","children":[["$","div",null,{"className":"flex justify-center","children":["$","span",null,{"className":"flex items-center gap-2","children":[["$","span",null,{"className":"relative flex h-9 w-9 items-center justify-center rounded-2xl bg-gradient-brand shadow-[0_8px_20px_-8px_rgb(91_69_184/0.8)]","children":["$","svg",null,{"width":"20","height":"20","viewBox":"0 0 24 24","fill":"white","aria-hidden":true,"children":["$","path",null,{"d":"M12 2.5l2.2 6.3 6.3 2.2-6.3 2.2L12 19.5l-2.2-6.3L3.5 11l6.3-2.2z"}]}]}],["$","span",null,{"className":"text-xl font-extrabold tracking-wide text-ink","children":"MOJO"}]]}]}],["$","h1",null,{"className":"mt-6 text-3xl font-extrabold","children":"Lost your MOJO?"}],["$","p",null,{"className":"mt-3 text-ink-soft","children":"This page doesn't exist. Let's get you back on track."}],"$Lf"]}]]}],["$L10"],"$L11"]}],"p":"$@12","v":"$13","s":"$a"}}]]
b:[["children",{"s":"/_not-found","h":49250,"d":{"r":["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}]}]]}],"p":"$@c","v":"$d","s":"$a"},"c":"$Qe"}]]
31:X
31:C
34:X
34:C
0:{"t":{"t":{"s":"","h":49234,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/mojo/_next/static/chunks/2gk-sc214nqvc.css","precedence":"next"}],["$","script","script-0",{"src":"/mojo/_next/static/chunks/2zdmxv_p9kk0q.js","async":true}]],["$","html",null,{"lang":"en","className":"-IWRBq_variable h-full antialiased","children":["$","body",null,{"className":"min-h-full font-sans","children":[["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}],"notFound":[["$","main",null,{"className":"flex min-h-screen items-center justify-center px-4","children":[["$","div",null,{"aria-hidden":true,"className":"pointer-events-none fixed inset-0 -z-10 overflow-hidden","children":[["$","div",null,{"className":"absolute -left-[10%] -top-[15%] h-[55vmax] w-[55vmax] animate-drift rounded-full bg-violet/30 blur-3xl"}],["$","div",null,{"className":"absolute -right-[15%] top-[20%] h-[50vmax] w-[50vmax] animate-drift-slow rounded-full bg-teal/25 blur-3xl"}],["$","div",null,{"className":"absolute bottom-[-25%] left-[25%] h-[45vmax] w-[45vmax] animate-drift rounded-full bg-amber/15 blur-3xl"}],["$","div",null,{"className":"absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgb(29_24_56/0.06)_1px,transparent_0)] [background-size:28px_28px]"}]]}],["$","div",null,{"className":"glass max-w-md rounded-blob p-10 text-center","children":[["$","div",null,{"className":"flex justify-center","children":["$","span",null,{"className":"flex items-center gap-2","children":[["$","span",null,{"className":"relative flex h-9 w-9 items-center justify-center rounded-2xl bg-gradient-brand shadow-[0_8px_20px_-8px_rgb(91_69_184/0.8)]","children":["$","svg",null,{"width":"20","height":"20","viewBox":"0 0 24 24","fill":"white","aria-hidden":true,"children":["$","path",null,{"d":"M12 2.5l2.2 6.3 6.3 2.2-6.3 2.2L12 19.5l-2.2-6.3L3.5 11l6.3-2.2z"}]}]}],["$","span",null,{"className":"text-xl font-extrabold tracking-wide text-ink","children":"MOJO"}]]}]}],["$","h1",null,{"className":"mt-6 text-3xl font-extrabold","children":"Lost your MOJO?"}],["$","p",null,{"className":"mt-3 text-ink-soft","children":"This page doesn't exist. Let's get you back on track."}],["$","$L7",null,{"href":"/","className":"mt-6 inline-flex rounded-full bg-ink px-6 py-3 font-bold text-white hover:bg-violet-deep","children":"Back home"}]]}]]}],[]]}],""]}]}]]}],"p":"$@8","v":"$9","s":"$a"},"c":"$Qb"},"h":{"r":["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L15",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}],["$","meta","2",{"name":"theme-color","content":"#8771d9"}]]}],["$","$L17",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$18",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"MOJO: Voice Journal & Mood Tracker for Sleep and Energy"}],["$","meta","1",{"name":"description","content":"MOJO is a voice journal and mood tracker. Say how your day went and MOJO logs your mood, sleep and activity, then shows you what lifts your energy."}],["$","meta","2",{"name":"application-name","content":"MOJO"}],["$","link","3",{"rel":"manifest","href":"/mojo/manifest.webmanifest"}],["$","meta","4",{"name":"keywords","content":"voice journal app,mood tracker app,mood journal,sleep and mood tracker,wellness app,mental health app,journaling app,energy tracker,MOJO app"}],["$","meta","5",{"name":"creator","content":"MOJO by Heylixir"}],["$","meta","6",{"name":"publisher","content":"MOJO by Heylixir"}],["$","meta","7",{"name":"robots","content":"index, follow"}],["$","meta","8",{"name":"googlebot","content":"index, follow, max-image-preview:large, max-snippet:-1"}],["$","meta","9",{"name":"category","content":"health & fitness"}],["$","link","10",{"rel":"canonical","href":"https://heylixir.com/mojo/"}],["$","meta","11",{"name":"format-detection","content":"telephone=no"}],["$","meta","12",{"property":"og:title","content":"MOJO: Voice Journal & Mood Tracker for Sleep and Energy"}],["$","meta","13",{"property":"og:description","content":"MOJO is a voice journal and mood tracker. Say how your day went and MOJO logs your mood, sleep and activity, then shows you what lifts your energy."}],"$L19","$L1a","$L1b","$L1c","$L1d","$L1e","$L1f","$L20","$L21","$L22","$L23","$L24","$L25","$L26","$L27","$L28","$L29","$L2a","$L2b","$L2c","$L2d","$L2e"]}]}],null]}],"$L2f"]}],"p":"$@30","v":"$31","s":"$a"}},"a":"$@32","u":"$@33","b":"V7l5rx--VvIyRBxJ_Drdz","r":"$34"}
35:I[97367,["$2"],"OutletBoundary"]
37:I[27201,["$2"],"IconMark"]
f:["$","$L7",null,{"href":"/","className":"mt-6 inline-flex rounded-full bg-ink px-6 py-3 font-bold text-white hover:bg-violet-deep","children":"Back home"}]
10:["$","script","script-0",{"src":"/mojo/_next/static/chunks/1elud1o77e445.js","async":true}]
11:["$","$L35",null,{"children":["$","$18",null,{"name":"Next.MetadataOutlet","children":"$@36"}]}]
19:["$","meta","14",{"property":"og:url","content":"https://heylixir.com/mojo/"}]
1a:["$","meta","15",{"property":"og:site_name","content":"MOJO"}]
1b:["$","meta","16",{"property":"og:locale","content":"en_US"}]
1c:["$","meta","17",{"property":"og:image","content":"https://heylixir.com/mojo/opengraph-image?f53dc6da951e64df"}]
1d:["$","meta","18",{"property":"og:image:type","content":"image/png"}]
1e:["$","meta","19",{"property":"og:image:width","content":"1200"}]
1f:["$","meta","20",{"property":"og:image:height","content":"630"}]
20:["$","meta","21",{"property":"og:image:alt","content":"MOJO: talk it out, find your MOJO"}]
21:["$","meta","22",{"property":"og:type","content":"website"}]
22:["$","meta","23",{"name":"twitter:card","content":"summary_large_image"}]
23:["$","meta","24",{"name":"twitter:title","content":"MOJO: Voice Journal & Mood Tracker for Sleep and Energy"}]
24:["$","meta","25",{"name":"twitter:description","content":"MOJO is a voice journal and mood tracker. Say how your day went and MOJO logs your mood, sleep and activity, then shows you what lifts your energy."}]
25:["$","meta","26",{"name":"twitter:image","content":"https://heylixir.com/mojo/opengraph-image?f53dc6da951e64df"}]
26:["$","meta","27",{"name":"twitter:image:alt","content":"MOJO: talk it out, find your MOJO"}]
27:["$","meta","28",{"name":"twitter:image:type","content":"image/png"}]
28:["$","meta","29",{"name":"twitter:image:width","content":"1200"}]
29:["$","meta","30",{"name":"twitter:image:height","content":"630"}]
2a:["$","link","31",{"rel":"icon","href":"https://heylixir.com/mojo/favicon.ico","sizes":"any"}]
2b:["$","link","32",{"rel":"icon","href":"https://heylixir.com/mojo/icon-192.png","type":"image/png","sizes":"192x192"}]
2c:["$","link","33",{"rel":"icon","href":"https://heylixir.com/mojo/icon-512.png","type":"image/png","sizes":"512x512"}]
2d:["$","link","34",{"rel":"apple-touch-icon","href":"https://heylixir.com/mojo/apple-touch-icon.png","sizes":"180x180"}]
2e:["$","$L37","35",{}]
2f:["$","meta",null,{"name":"next-size-adjust","content":""}]
33:false
36:null
32:null
c:"$undefined"
8:"$undefined"
30:"$undefined"
12:"$undefined"
