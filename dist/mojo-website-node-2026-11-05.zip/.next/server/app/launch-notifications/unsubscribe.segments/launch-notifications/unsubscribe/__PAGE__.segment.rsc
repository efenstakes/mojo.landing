1:"$Sreact.fragment"
2:"/mojo/_next/static/chunks/0wj0noag-9_fs.js"
3:I[39756,["$2"],"default"]
4:I[37457,["$2"],"default"]
5:"/mojo/_next/static/chunks/2zdmxv_p9kk0q.js"
6:"/mojo/_next/static/chunks/1u0gjueimkba1.js"
7:"/mojo/_next/static/chunks/2iz_avc5ui0jt.js"
8:I[22016,["$5","$6","$7"],""]
12:I[2874,["$5","$6","$7"],"default"]
13:"$Sreact.suspense"
14:I[74031,["$5","$6","$7"],"default"]
21:"ViewportBoundary"
22:I[97367,["$2"],"$21"]
23:"MetadataBoundary"
24:I[97367,["$2"],"$23"]
:HL["/mojo/_next/static/chunks/2gk-sc214nqvc.css","style"]
a:X
a:C
b:X
b:300
b:C
e:X
e:C
20:X
20:C
11:[["children",{"s":"__PAGE__","h":49314,"d":{"r":["$","$1","c",{"children":[[["$","div",null,{"aria-hidden":true,"className":"pointer-events-none fixed inset-0 -z-10 overflow-hidden","children":[["$","div",null,{"className":"absolute -left-[10%] -top-[15%] h-[55vmax] w-[55vmax] animate-drift rounded-full bg-violet/30 blur-3xl"}],["$","div",null,{"className":"absolute -right-[15%] top-[20%] h-[50vmax] w-[50vmax] animate-drift-slow rounded-full bg-teal/25 blur-3xl"}],["$","div",null,{"className":"absolute bottom-[-25%] left-[25%] h-[45vmax] w-[45vmax] animate-drift rounded-full bg-amber/15 blur-3xl"}],["$","div",null,{"className":"absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgb(29_24_56/0.06)_1px,transparent_0)] [background-size:28px_28px]"}]]}],["$","$L12",null,{}],["$","main",null,{"id":"main","children":["$","section",null,{"className":"flex min-h-[70vh] items-center justify-center px-4 pb-16 pt-32","children":["$","div",null,{"className":"glass max-w-md rounded-blob p-10 text-center","children":["$","$13",null,{"fallback":["$","p",null,{"className":"text-ink-soft","children":"Loading…"}],"children":["$","$L14",null,{}]}]}]}]}],["$","footer",null,{"className":"px-4 pb-10 pt-6","children":[["$","div",null,{"className":"glass mx-auto grid max-w-6xl gap-10 rounded-blob px-8 py-10 md:grid-cols-[1fr_2.4fr]","children":[["$","div",null,{"className":"max-w-xs","children":[["$","span",null,{"className":"flex items-center gap-2","children":[["$","span",null,{"className":"relative flex h-9 w-9 items-center justify-center rounded-2xl bg-gradient-brand shadow-[0_8px_20px_-8px_rgb(91_69_184/0.8)]","children":"$L15"}],"$L16"]}],"$L17","$L18"]}],"$L19"]}],"$L1a"]}],"$L1b"],["$L1c","$L1d"],"$L1e"]}],"p":"$@1f","v":"$20","s":"$b"}}]]
f:[["children",{"s":"unsubscribe","h":49250,"d":{"r":["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}]}]]}],"p":"$@10","v":"$e","s":"$b"},"c":"$Q11"}]]
c:[["children",{"s":"launch-notifications","h":49250,"d":{"r":["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}]}]]}],"p":"$@d","v":"$e","s":"$b"},"c":"$Qf"}]]
3a:X
3a:C
3d:X
3d:C
0:{"t":{"t":{"s":"","h":49234,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/mojo/_next/static/chunks/2gk-sc214nqvc.css","precedence":"next"}],["$","script","script-0",{"src":"/mojo/_next/static/chunks/2zdmxv_p9kk0q.js","async":true}]],["$","html",null,{"lang":"en","className":"-IWRBq_variable h-full antialiased","children":["$","body",null,{"className":"min-h-full font-sans","children":[["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}],"notFound":[["$","main",null,{"className":"flex min-h-screen items-center justify-center px-4","children":[["$","div",null,{"aria-hidden":true,"className":"pointer-events-none fixed inset-0 -z-10 overflow-hidden","children":[["$","div",null,{"className":"absolute -left-[10%] -top-[15%] h-[55vmax] w-[55vmax] animate-drift rounded-full bg-violet/30 blur-3xl"}],["$","div",null,{"className":"absolute -right-[15%] top-[20%] h-[50vmax] w-[50vmax] animate-drift-slow rounded-full bg-teal/25 blur-3xl"}],["$","div",null,{"className":"absolute bottom-[-25%] left-[25%] h-[45vmax] w-[45vmax] animate-drift rounded-full bg-amber/15 blur-3xl"}],["$","div",null,{"className":"absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgb(29_24_56/0.06)_1px,transparent_0)] [background-size:28px_28px]"}]]}],["$","div",null,{"className":"glass max-w-md rounded-blob p-10 text-center","children":[["$","div",null,{"className":"flex justify-center","children":["$","span",null,{"className":"flex items-center gap-2","children":[["$","span",null,{"className":"relative flex h-9 w-9 items-center justify-center rounded-2xl bg-gradient-brand shadow-[0_8px_20px_-8px_rgb(91_69_184/0.8)]","children":["$","svg",null,{"width":"20","height":"20","viewBox":"0 0 24 24","fill":"white","aria-hidden":true,"children":["$","path",null,{"d":"M12 2.5l2.2 6.3 6.3 2.2-6.3 2.2L12 19.5l-2.2-6.3L3.5 11l6.3-2.2z"}]}]}],["$","span",null,{"className":"text-xl font-extrabold tracking-wide text-ink","children":"MOJO"}]]}]}],["$","h1",null,{"className":"mt-6 text-3xl font-extrabold","children":"Lost your MOJO?"}],["$","p",null,{"className":"mt-3 text-ink-soft","children":"This page doesn't exist. Let's get you back on track."}],["$","$L8",null,{"href":"/","className":"mt-6 inline-flex rounded-full bg-ink px-6 py-3 font-bold text-white hover:bg-violet-deep","children":"Back home"}]]}]]}],[]]}],""]}]}]]}],"p":"$@9","v":"$a","s":"$b"},"c":"$Qc"},"h":{"r":["$","$1","h",{"children":[null,["$","$L22",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}],["$","meta","2",{"name":"theme-color","content":"#8771d9"}]]}],["$","$L24",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$13",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Unsubscribe · MOJO"}],["$","meta","1",{"name":"description","content":"MOJO is a voice journal and mood tracker. Say how your day went and MOJO logs your mood, sleep and activity, then shows you what lifts your energy."}],["$","meta","2",{"name":"application-name","content":"MOJO"}],["$","link","3",{"rel":"manifest","href":"/mojo/manifest.webmanifest"}],["$","meta","4",{"name":"keywords","content":"voice journal app,mood tracker app,mood journal,sleep and mood tracker,wellness app,mental health app,journaling app,energy tracker,MOJO app"}],["$","meta","5",{"name":"creator","content":"MOJO by Heylixir"}],["$","meta","6",{"name":"publisher","content":"MOJO by Heylixir"}],["$","meta","7",{"name":"robots","content":"noindex, nofollow"}],["$","meta","8",{"name":"category","content":"health & fitness"}],["$","link","9",{"rel":"canonical","href":"https://heylixir.com/mojo/"}],["$","meta","10",{"name":"format-detection","content":"telephone=no"}],["$","meta","11",{"property":"og:title","content":"MOJO: Voice Journal & Mood Tracker for Sleep and Energy"}],["$","meta","12",{"property":"og:description","content":"MOJO is a voice journal and mood tracker. Say how your day went and MOJO logs your mood, sleep and activity, then shows you what lifts your energy."}],["$","meta","13",{"property":"og:url","content":"https://heylixir.com/mojo/"}],["$","meta","14",{"property":"og:site_name","content":"MOJO"}],["$","meta","15",{"property":"og:locale","content":"en_US"}],"$L25","$L26","$L27","$L28","$L29","$L2a","$L2b","$L2c","$L2d","$L2e","$L2f","$L30","$L31","$L32","$L33","$L34","$L35","$L36","$L37"]}]}],null]}],"$L38"]}],"p":"$@39","v":"$3a","s":"$b"}},"a":"$@3b","u":"$@3c","b":"V7l5rx--VvIyRBxJ_Drdz","r":"$3d"}
3e:I[60038,["$5","$6","$7"],"default"]
3f:I[97367,["$2"],"OutletBoundary"]
41:I[27201,["$2"],"IconMark"]
15:["$","svg",null,{"width":"20","height":"20","viewBox":"0 0 24 24","fill":"white","aria-hidden":true,"children":["$","path",null,{"d":"M12 2.5l2.2 6.3 6.3 2.2-6.3 2.2L12 19.5l-2.2-6.3L3.5 11l6.3-2.2z"}]}]
16:["$","span",null,{"className":"text-xl font-extrabold tracking-wide text-ink","children":"MOJO"}]
17:["$","p",null,{"className":"mt-4 text-sm leading-relaxed text-ink-soft","children":"Talk it out. Feel it out. Find your MOJO."}]
18:["$","p",null,{"className":"mt-4 text-sm text-ink-soft","children":["$","a",null,{"href":"mailto:mojo@heylixir.com","className":"hover:text-ink","children":"mojo@heylixir.com"}]}]
19:["$","div",null,{"className":"grid grid-cols-2 gap-10 text-sm sm:grid-cols-3","children":[["$","nav",null,{"aria-label":"Product","children":[["$","p",null,{"className":"font-bold","children":"Product"}],["$","ul",null,{"className":"mt-3 space-y-2 text-ink-soft","children":[["$","li","/#how-it-works",{"children":["$","$L8",null,{"href":"/#how-it-works","className":"hover:text-ink","children":"How it works"}]}],["$","li","/#features",{"children":["$","$L8",null,{"href":"/#features","className":"hover:text-ink","children":"Features"}]}],["$","li","/#halo",{"children":["$","$L8",null,{"href":"/#halo","className":"hover:text-ink","children":"Halo AI"}]}],["$","li","/#faq",{"children":["$","$L8",null,{"href":"/#faq","className":"hover:text-ink","children":"FAQ"}]}],["$","li","/guides",{"children":["$","$L8",null,{"href":"/guides","className":"hover:text-ink","children":"All guides"}]}]]}]]}],["$","nav",null,{"aria-label":"Popular guides","className":"col-span-2 sm:col-span-1","children":[["$","p",null,{"className":"font-bold","children":"Popular guides"}],["$","ul",null,{"className":"mt-3 space-y-2 text-ink-soft","children":[["$","li","managing-mental-health-working-9-to-5",{"children":["$","$L8",null,{"href":"/guides/managing-mental-health-working-9-to-5","className":"hover:text-ink","children":"Managing Mental Health While Working a 9-5"}]}],["$","li","managing-mental-health-at-university",{"children":["$","$L8",null,{"href":"/guides/managing-mental-health-at-university","className":"hover:text-ink","children":"Managing Mental Health at University: A Student Guide"}]}],["$","li","best-mental-health-apps-for-students",{"children":["$","$L8",null,{"href":"/guides/best-mental-health-apps-for-students","className":"hover:text-ink","children":"Best Mental Health Apps for Students"}]}],["$","li","how-to-calm-anxiety",{"children":["$","$L8",null,{"href":"/guides/how-to-calm-anxiety","className":"hover:text-ink","children":"How to Calm Anxiety: 10 Techniques That Help"}]}],["$","li","how-to-reduce-stress",{"children":["$","$L8",null,{"href":"/guides/how-to-reduce-stress","className":"hover:text-ink","children":"How to Reduce Stress: 12 Techniques That Work"}]}],["$","li","signs-of-burnout-at-work",{"children":["$","$L8",null,{"href":"/guides/signs-of-burnout-at-work","className":"hover:text-ink","children":"Signs of Burnout at Work and How to Recover"}]}],["$","li","how-to-recover-from-burnout",{"children":["$","$L8",null,{"href":"/guides/how-to-recover-from-burnout","className":"hover:text-ink","children":"How to Recover From Burnout: A Step-by-Step Plan"}]}]]}]]}],["$","nav",null,{"aria-label":"Company","className":"row-start-1 sm:row-auto col-start-2 sm:col-auto","children":[["$","p",null,{"className":"font-bold","children":"Company"}],["$","ul",null,{"className":"mt-3 space-y-2 text-ink-soft","children":[[["$","li","/about",{"children":["$","$L8",null,{"href":"/about","className":"hover:text-ink","children":"About"}]}],["$","li","/privacy",{"children":["$","$L8",null,{"href":"/privacy","className":"hover:text-ink","children":"Privacy"}]}],["$","li","/terms",{"children":["$","$L8",null,{"href":"/terms","className":"hover:text-ink","children":"Terms"}]}],["$","li","/delete-account",{"children":["$","$L8",null,{"href":"/delete-account","className":"hover:text-ink","children":"Delete your account"}]}]],["$","li",null,{"children":["$","a",null,{"href":"mailto:mojo@heylixir.com","className":"hover:text-ink","children":"Contact"}]}]]}]]}]]}]
1a:["$","p",null,{"className":"mx-auto mt-6 max-w-6xl px-4 text-center text-xs text-ink-soft","children":["© ",2026," ","MOJO by Heylixir",". MOJO supports everyday wellbeing and is not a medical device. If you're in crisis, call your local emergency number or a crisis line such as 988 (US) or 116 123 (UK)."]}]
1b:["$","$L3e",null,{}]
1c:["$","script","script-0",{"src":"/mojo/_next/static/chunks/1u0gjueimkba1.js","async":true}]
1d:["$","script","script-1",{"src":"/mojo/_next/static/chunks/2iz_avc5ui0jt.js","async":true}]
1e:["$","$L3f",null,{"children":["$","$13",null,{"name":"Next.MetadataOutlet","children":"$@40"}]}]
25:["$","meta","16",{"property":"og:image","content":"https://heylixir.com/mojo/opengraph-image?f53dc6da951e64df"}]
26:["$","meta","17",{"property":"og:image:type","content":"image/png"}]
27:["$","meta","18",{"property":"og:image:width","content":"1200"}]
28:["$","meta","19",{"property":"og:image:height","content":"630"}]
29:["$","meta","20",{"property":"og:image:alt","content":"MOJO: talk it out, find your MOJO"}]
2a:["$","meta","21",{"property":"og:type","content":"website"}]
2b:["$","meta","22",{"name":"twitter:card","content":"summary_large_image"}]
2c:["$","meta","23",{"name":"twitter:title","content":"MOJO: Voice Journal & Mood Tracker for Sleep and Energy"}]
2d:["$","meta","24",{"name":"twitter:description","content":"MOJO is a voice journal and mood tracker. Say how your day went and MOJO logs your mood, sleep and activity, then shows you what lifts your energy."}]
2e:["$","meta","25",{"name":"twitter:image","content":"https://heylixir.com/mojo/opengraph-image?f53dc6da951e64df"}]
2f:["$","meta","26",{"name":"twitter:image:alt","content":"MOJO: talk it out, find your MOJO"}]
30:["$","meta","27",{"name":"twitter:image:type","content":"image/png"}]
31:["$","meta","28",{"name":"twitter:image:width","content":"1200"}]
32:["$","meta","29",{"name":"twitter:image:height","content":"630"}]
33:["$","link","30",{"rel":"icon","href":"https://heylixir.com/mojo/favicon.ico","sizes":"any"}]
34:["$","link","31",{"rel":"icon","href":"https://heylixir.com/mojo/icon-192.png","type":"image/png","sizes":"192x192"}]
35:["$","link","32",{"rel":"icon","href":"https://heylixir.com/mojo/icon-512.png","type":"image/png","sizes":"512x512"}]
36:["$","link","33",{"rel":"apple-touch-icon","href":"https://heylixir.com/mojo/apple-touch-icon.png","sizes":"180x180"}]
37:["$","$L41","34",{}]
38:["$","meta",null,{"name":"next-size-adjust","content":""}]
3c:false
40:null
3b:null
10:"$undefined"
d:"$undefined"
9:"$undefined"
39:"$undefined"
1f:"$undefined"
