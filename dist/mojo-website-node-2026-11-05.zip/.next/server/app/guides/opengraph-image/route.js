var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/guides/opengraph-image/route.js")
R.c("server/chunks/[externals]__050te6u0lo3n4._.js")
R.c("server/chunks/_0ccmm1hxpnmtf._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/node_modules_next_0g8xe7c6fvfgl._.js")
R.c("server/chunks/_1fd2vvtvn-u2b._.js")
R.c("server/chunks/_next-internal_server_app_guides_opengraph-image_route_actions_1te0vidt5k381.js")
R.m(61166)
module.exports=R.m(61166).exports
