var R=require("../../chunks/[turbopack]_runtime.js")("server/app/llms.txt/route.js")
R.c("server/chunks/[root-of-the-server]__0nb5qxojbqe-j._.js")
R.c("server/chunks/_02angetmc4jzk._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/src_content_guides_ts_0dg-hjb0k_n9h._.js")
R.c("server/chunks/_next-internal_server_app_llms_txt_route_actions_09lmvgwthkqn5.js")
R.m(69569)
module.exports=R.m(69569).exports
