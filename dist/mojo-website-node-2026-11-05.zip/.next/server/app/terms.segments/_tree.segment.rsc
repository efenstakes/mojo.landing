:HL["/mojo/_next/static/chunks/2gk-sc214nqvc.css","style"]
:HL["/mojo/_next/static/media/d8aeca813a9ab546-s.p.18rizl4rsrl42.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
2:[["children",{"s":"__PAGE__","h":49314}]]
1:[["children",{"s":"terms","h":49250,"c":"$Q2"}]]
0:{"b":"V7l5rx--VvIyRBxJ_Drdz","t":{"t":{"s":"","h":49234,"c":"$Q1"}}}
