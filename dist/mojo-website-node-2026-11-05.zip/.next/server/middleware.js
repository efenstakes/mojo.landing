var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__166pbwd8x2etx._.js")
R.c("server/chunks/[root-of-the-server]__0kss50s430u7x._.js")
R.m(89997)
module.exports=R.m(89997).exports
