module.exports=[21706,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_guides_opengraph-image_route_actions_1te0vidt5k381.js.map