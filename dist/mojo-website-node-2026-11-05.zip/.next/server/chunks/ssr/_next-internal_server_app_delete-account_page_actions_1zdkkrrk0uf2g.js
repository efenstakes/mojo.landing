module.exports=[33152,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_delete-account_page_actions_1zdkkrrk0uf2g.js.map