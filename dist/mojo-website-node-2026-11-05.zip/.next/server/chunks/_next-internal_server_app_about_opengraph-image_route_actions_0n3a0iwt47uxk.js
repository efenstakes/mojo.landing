module.exports=[71134,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_about_opengraph-image_route_actions_0n3a0iwt47uxk.js.map