globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/V7l5rx--VvIyRBxJ_Drdz/_buildManifest.js",
    "static/V7l5rx--VvIyRBxJ_Drdz/_ssgManifest.js",
    "static/V7l5rx--VvIyRBxJ_Drdz/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0uk63h0tuavo5.js",
    "static/chunks/0wkt4v6rmhk4q.js",
    "static/chunks/2xbu7vbjlke9r.js",
    "static/chunks/1gv60scp74bjf.js",
    "static/chunks/turbopack-24b-uo5er84_m.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/0uk63h0tuavo5.js",
        "static/chunks/0wkt4v6rmhk4q.js",
        "static/chunks/2xbu7vbjlke9r.js",
        "static/chunks/1gv60scp74bjf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/0uk63h0tuavo5.js",
        "static/chunks/0wkt4v6rmhk4q.js",
        "static/chunks/2xbu7vbjlke9r.js",
        "static/chunks/1gv60scp74bjf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/0uk63h0tuavo5.js",
        "static/chunks/0wkt4v6rmhk4q.js",
        "static/chunks/2xbu7vbjlke9r.js",
        "static/chunks/1gv60scp74bjf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/about/page": {
      "otherChunks": [
        "static/chunks/0uk63h0tuavo5.js",
        "static/chunks/0wkt4v6rmhk4q.js",
        "static/chunks/2xbu7vbjlke9r.js",
        "static/chunks/1gv60scp74bjf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/delete-account/page": {
      "otherChunks": [
        "static/chunks/0uk63h0tuavo5.js",
        "static/chunks/0wkt4v6rmhk4q.js",
        "static/chunks/2xbu7vbjlke9r.js",
        "static/chunks/1gv60scp74bjf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/guides/page": {
      "otherChunks": [
        "static/chunks/0uk63h0tuavo5.js",
        "static/chunks/0wkt4v6rmhk4q.js",
        "static/chunks/2xbu7vbjlke9r.js",
        "static/chunks/1gv60scp74bjf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/guides/[slug]/page": {
      "otherChunks": [
        "static/chunks/0uk63h0tuavo5.js",
        "static/chunks/0wkt4v6rmhk4q.js",
        "static/chunks/2xbu7vbjlke9r.js",
        "static/chunks/1gv60scp74bjf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/launch-notifications/unsubscribe/page": {
      "otherChunks": [
        "static/chunks/0uk63h0tuavo5.js",
        "static/chunks/0wkt4v6rmhk4q.js",
        "static/chunks/2xbu7vbjlke9r.js",
        "static/chunks/1gv60scp74bjf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/privacy/page": {
      "otherChunks": [
        "static/chunks/0uk63h0tuavo5.js",
        "static/chunks/0wkt4v6rmhk4q.js",
        "static/chunks/2xbu7vbjlke9r.js",
        "static/chunks/1gv60scp74bjf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/terms/page": {
      "otherChunks": [
        "static/chunks/0uk63h0tuavo5.js",
        "static/chunks/0wkt4v6rmhk4q.js",
        "static/chunks/2xbu7vbjlke9r.js",
        "static/chunks/1gv60scp74bjf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
